package com.nimap.catogery_product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CatogeryProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(CatogeryProductApplication.class, args);
	}

}
