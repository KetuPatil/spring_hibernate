A hibernate project mapped with Database using various annotations where user can perform CRUD operations using the project.
